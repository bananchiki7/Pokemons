import { root } from "./root";

export function loader() {
    root.loader.classList.toggle("is-hidden");
}